import requests
from datetime import datetime
from zoneinfo import ZoneInfo
from firebase_admin import firestore
from django.conf import settings

db = firestore.client()

def uvi_level(uvi):
    if uvi is None:
        return "Unknown"
    if uvi <= 2:
        return "Low"
    elif uvi <= 5:
        return "Moderate"
    elif uvi <= 7:
        return "High"
    elif uvi <= 10:
        return "Very High"
    else:
        return "Extreme"

def get_lat_lon(city_name, api_key):
    geo_url = "http://api.openweathermap.org/geo/1.0/direct"
    params = {'q': city_name, 'limit': 1, 'appid': api_key}
    response = requests.get(geo_url, params=params)
    response.raise_for_status()
    data = response.json()
    if data:
        return data[0]['lat'], data[0]['lon']
    return None, None

def save_weather_forecast(city_name):
    API_KEY = settings.OPENWEATHER_API_KEY
    lat, lon = get_lat_lon(city_name, API_KEY)
    if lat is None or lon is None:
        raise Exception("도시명을 찾을 수 없습니다.")

    url = "https://api.openweathermap.org/data/3.0/onecall"
    params = {'lat': lat, 'lon': lon, 'appid': API_KEY, 'units': 'metric', 'exclude': 'minutely'}
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()

    kst = ZoneInfo('Asia/Seoul')
    hourly_data = data.get("hourly", [])[:48]
    alerts = data.get("alerts", [])

    daily_groups = {}
    for hour in hourly_data:
        dt_obj = datetime.utcfromtimestamp(hour.get("dt", 0)).replace(tzinfo=ZoneInfo("UTC")).astimezone(kst)
        date_str = dt_obj.strftime("%Y%m%d")
        time_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")

        entry = {
            "time": time_str,
            "temp": hour.get("temp"),
            "feels_like": hour.get("feels_like"),
            "humidity": hour.get("humidity"),
            "wind_speed": hour.get("wind_speed"),
            "uvi_level": uvi_level(hour.get("uvi")),
            "sunlight": hour.get("clouds"),
            "pop": hour.get("pop"),
            "rain": hour.get("rain", {}).get("1h", 0),
            "snow": hour.get("snow", {}).get("1h", 0),
            "clouds": hour.get("clouds"),
            "weather": hour.get("weather", [{}])[0]
        }
        daily_groups.setdefault(date_str, []).append(entry)

    for date_str, entries in daily_groups.items():
        doc_key = f"{city_name}_{date_str}"
        db.collection("weather_forecasts").document(doc_key).set({
            "city": city_name,
            "date": date_str,
            "hourly_forecasts": entries,
            "alerts": alerts
        })

def save_air_pollution(city_name):
    API_KEY = settings.OPENWEATHER_API_KEY
    lat, lon = get_lat_lon(city_name, API_KEY)
    if lat is None or lon is None:
        raise Exception("도시명을 찾을 수 없습니다.")

    url = f"http://api.openweathermap.org/data/2.5/air_pollution"
    params = {'lat': lat, 'lon': lon, 'appid': API_KEY}
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()
    air_info = data.get("list", [])[0] if data.get("list") else {}

    kst = ZoneInfo('Asia/Seoul')
    today = datetime.now(kst).strftime("%Y%m%d")
    doc_key = f"{city_name}_{today}"
    db.collection("air_quality").document(doc_key).set({
        "city": city_name,
        "date": today,
        "air": air_info
    })
